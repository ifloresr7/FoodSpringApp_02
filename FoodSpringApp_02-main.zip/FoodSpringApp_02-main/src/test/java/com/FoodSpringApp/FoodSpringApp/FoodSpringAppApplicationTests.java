package com.FoodSpringApp.FoodSpringApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodSpringAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
