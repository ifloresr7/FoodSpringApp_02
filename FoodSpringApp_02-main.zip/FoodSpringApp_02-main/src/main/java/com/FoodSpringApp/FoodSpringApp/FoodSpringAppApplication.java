package com.FoodSpringApp.FoodSpringApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodSpringAppApplication {
	public static void main(String[] args) {
		SpringApplication.run(FoodSpringAppApplication.class, args);
	}
}